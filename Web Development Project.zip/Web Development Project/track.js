// Example JavaScript to simulate changing the progress bar based on order status
const progressBar = document.querySelector('.progress-bar span');
const orderStatus = 'Shipped';  // Dynamically fetch the order status

switch (orderStatus) {
    case 'Processing':
        progressBar.style.width = '25%';
        break;
    case 'Shipped':
        progressBar.style.width = '50%';
        break;
    case 'In Transit':
        progressBar.style.width = '75%';
        break;
    case 'Delivered':
        progressBar.style.width = '100%';
        break;
}