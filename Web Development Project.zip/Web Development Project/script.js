class ImageSlider {
    constructor(container) {
        this.container = container;
        this.slides = container.querySelector('.slides');
        this.slideElements = container.querySelectorAll('.slide');
        this.dots = container.querySelectorAll('.dot');
        this.currentSlide = 0;

        this.initEventListeners();
        this.startAutoSlide();
    }

    initEventListeners() {
        this.dots.forEach(dot => {
            dot.addEventListener('click', (e) => {
                const slideIndex = parseInt(e.target.getAttribute('data-slide'));
                this.goToSlide(slideIndex);
            });
        });
    }

    goToSlide(slideIndex) {
        this.dots.forEach(dot => dot.classList.remove('active'));
        this.currentSlide = slideIndex;
        this.slides.style.transform = translateX(-${slideIndex * 100}%);
        this.dots[slideIndex].classList.add('active');
    }

    nextSlide() {
        this.currentSlide = (this.currentSlide + 1) % this.slideElements.length;
        this.goToSlide(this.currentSlide);
    }

    startAutoSlide() {
        this.slideInterval = setInterval(() => {
            this.nextSlide();
        }, 10000); // 10 seconds
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const sliderContainer = document.querySelector('.slider-container');
    new ImageSlider(sliderContainer);
});